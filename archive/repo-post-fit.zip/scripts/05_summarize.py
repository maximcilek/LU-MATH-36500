import arviz as az
import pandas as pd

trace = az.from_netcdf("data/generated/bhmm_trace_full.nc")
summary = az.summary(trace)
summary.to_csv("tables/bhmm_posterior_summary.csv")

key = [
    "bhmm::e_R0", "bhmm::r_R0", "bhmm::n_R0",
    "bhmm::e_scale", "bhmm::r_scale",
    "bhmm::e_alpha_nb", "bhmm::r_alpha_nb",
    "bhmm::class_re_sd", "bhmm::sigma_rw_e", "bhmm::sigma_rw_r",
    "bhmm::hyper_log_R0_mu", "bhmm::hyper_log_R0_sd",
]

found = [p for p in key if p in summary.index]
missing = [p for p in key if p not in summary.index]

print(summary.loc[found, ["mean", "sd", "eti89_lb", "eti89_ub", "r_hat", "ess_bulk"]].round(4).to_string())

if missing:
    print(f"\nNot in index (likely Deterministic vars): {missing}")
    # Try without prefix
    alt = [p.replace("bhmm::", "") for p in missing]
    found_alt = [p for p in alt if p in summary.index]
    if found_alt:
        print(summary.loc[found_alt, ["mean", "sd", "eti89_lb", "eti89_ub", "r_hat", "ess_bulk"]].round(4).to_string())