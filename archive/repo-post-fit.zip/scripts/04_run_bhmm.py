"""
scripts/04_run_bhmm.py
----------------------
Run the unified Bayesian Hierarchical Mechanistic Model (BHMM) and save all outputs.

Usage:
    # Production run (4 chains x 2000 draws; ~45 min on a modern laptop)
    python scripts/04_run_bhmm.py --draws 2000 --chains 4 --target_accept 0.95 --seed 20260914

    # Quick sanity check (2 chains x 300 draws; ~5 min)
    python scripts/04_run_bhmm.py --quick

Outputs (written to tables/ and data/generated/):
    tables/bhmm_posterior_summary.csv        — full posterior summary (all parameters)
    tables/bhmm_convergence_diagnostics.csv  — Rhat, ESS per parameter
    tables/zombie_prior_predictive_summary.csv
    data/generated/bhmm_trace_full.nc        — ArviZ InferenceData (NetCDF4 via h5netcdf)
    data/generated/zombie_prior_pred.npz     — zombie prior-predictive arrays
    figures/bhmm/R0_comparison.png           — cross-disease R0 posterior plot
    figures/bhmm/ppc_panel.png               — posterior predictive check panel
    figures/bhmm/convergence_panel.png       — Rhat / ESS diagnostic plot

Data sources (all real published data; no synthetic data in any likelihood):
    Ebola     : RECON outbreaks R package / Khan et al. (1999) J Infect Dis 179:S76
    Norovirus : RECON outbreaks R package / O'Neill & Marks (2005) Stat Med 24:2011
    Influenza : Murray (1978) BMJ 1(6112):587 / RECON outbreaks R package
    Zombie    : Prior-predictive ONLY (no observations; see prior_predictive.py)

NOTE: Zombie raw data in data/raw/zombie/ are synthetic SEZR simulation outputs
      and are NEVER read by this script. They are retained for provenance only.

Seed: 20260914 — use this seed for reproducibility and on-prem comparison.
"""
import sys
import argparse
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", category=FutureWarning)
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd
import pymc as pm
import arviz as az
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

from core.bhmm.bhmm_model import build_full_bhmm
from core.bhmm.prior_predictive import zombie_prior_predictive, summarise_prior_predictive

ROOT = Path(__file__).resolve().parents[1]
CAN  = ROOT / "data" / "canonical"
GEN  = ROOT / "data" / "generated"
TAB  = ROOT / "tables"
FIGB = ROOT / "figures" / "bhmm"

for d in [GEN, TAB, FIGB]:
    d.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_data():
    """Load analysis-ready canonical files."""
    ebola_df = pd.read_csv(
        CAN / "ebola_kikwit_1995_analysis_ready.csv", parse_dates=["date"]
    )
    noro_df = pd.read_csv(
        CAN / "norovirus_derbyshire_2001_analysis_ready.csv"
    )
    flu_df = pd.read_csv(
        CAN / "influenza_england_1978_analysis_ready.csv", parse_dates=["date"]
    )

    print(f"Ebola eligible rows       : {ebola_df.analysis_eligible.sum()} / {len(ebola_df)}")
    print(f"Norovirus ill outcome     : {noro_df.ill.sum()} / {len(noro_df)}")
    print(f"Influenza in_bed days     : {len(flu_df)} (N={flu_df.N.iloc[0]}, peak={flu_df.in_bed.max()})")

    return ebola_df, noro_df, flu_df


# ---------------------------------------------------------------------------
# Zombie prior predictive (always runs; no data; no likelihood)
# ---------------------------------------------------------------------------

def run_zombie_prior_predictive():
    """
    Run prior-predictive for zombie SEZR.

    No real zombie data exists. This propagates the assumed SEZR parameters
    (from zombie_sezr_prior_params.json) through the ODE to produce a
    prior predictive distribution over epidemic trajectories.

    This is methodologically equivalent to expert-elicited prior predictive
    checks (Gelman et al. 2020, BDA3 Ch. 6). It is NOT synthetic data
    generation — no observations are created and no likelihood is computed.
    """
    print("\n[ZOMBIE] Prior-predictive inference (no data; no likelihood)")
    pp = zombie_prior_predictive(
        CAN / "zombie_sezr_prior_params.json",
        n_samples=1000, seed=20260914,
    )
    summ = summarise_prior_predictive(pp)
    summ.to_csv(TAB / "zombie_prior_predictive_summary.csv", index=False)
    np.savez(
        str(GEN / "zombie_prior_pred.npz"),
        I_t_samples=pp["I_t_samples"],
        R0_samples=pp["R0_samples"],
        peak_I_samples=pp["peak_I_samples"],
        peak_day_samples=pp["peak_day_samples"],
    )
    print("  Zombie prior predictive:")
    print(summ.to_string(index=False))
    return pp


# ---------------------------------------------------------------------------
# BHMM sampling and output saving
# ---------------------------------------------------------------------------

def run_bhmm(ebola_df, noro_df, flu_df, draws, chains, target_accept, seed):
    """Sample the BHMM posterior."""
    model = build_full_bhmm(ebola_df, noro_df, flu_df)
    with model:
        trace = pm.sample(
            draws=draws,
            tune=max(draws // 2, 500),
            chains=chains,
            target_accept=target_accept,
            random_seed=seed,
            progressbar=True,
            cores=1,
        )
    return trace


def save_outputs(trace, out_name="bhmm_trace_full"):
    """Save trace, posterior summary, and convergence diagnostics."""
    # Full trace (NetCDF4 via h5netcdf; requires: pip install h5py)
    nc_path = GEN / f"{out_name}.nc"
    trace.to_netcdf(str(nc_path), engine="h5netcdf")
    print(f"  Trace saved : {nc_path}")

    # Posterior summary (all parameters)
    summary = az.summary(trace)
    summary.to_csv(TAB / "bhmm_posterior_summary.csv")
    print(f"  Posterior summary: {len(summary)} rows")

    # Convergence diagnostics table
    diag = summary[["mean", "sd", "r_hat", "ess_bulk", "ess_tail"]]
    diag.to_csv(TAB / "bhmm_convergence_diagnostics.csv")

    bad_rhat = diag[diag.r_hat > 1.05]
    low_ess  = diag[diag.ess_bulk < 100]
    divs     = int(trace.sample_stats.diverging.sum())

    print(f"\n  Divergences        : {divs}")
    print(f"  Rhat > 1.05        : {len(bad_rhat)} parameters")
    print(f"  ESS_bulk < 100     : {len(low_ess)} parameters")

    if len(bad_rhat) > 0:
        print(f"  Warning — bad Rhat : {list(bad_rhat.index)[:5]}")
    if divs > 0:
        print(f"  Warning — {divs} divergences detected. Consider increasing target_accept.")

    # Key parameter summary
    key = ["bhmm::e_R0", "bhmm::flu_R0", "bhmm::n_R0",
           "bhmm::log_intercept_e", "bhmm::log_intercept_flu",
           "bhmm::sigma_rw_e", "bhmm::sigma_rw_flu",
           "bhmm::e_alpha_nb", "bhmm::flu_alpha_nb",
           "bhmm::class_re_sd",
           "bhmm::hyper_log_R0_mu", "bhmm::hyper_log_R0_sd"]
    avail = [p for p in key if p in summary.index]
    print("\n  KEY PARAMETERS:")
    print(summary.loc[avail, ["mean", "sd", "eti89_lb", "eti89_ub", "r_hat", "ess_bulk"]].round(4).to_string())

    return summary, diag


# ---------------------------------------------------------------------------
# Diagnostic figures
# ---------------------------------------------------------------------------

def make_r0_comparison(trace, zombie_pp):
    """Cross-disease R0 posterior comparison figure."""
    post = trace.posterior
    fig, axes = plt.subplots(1, 4, figsize=(18, 5))
    fig.suptitle(
        "BHMM posterior: R\u2080 comparison across diseases",
        fontsize=12, fontweight="bold", color="#1F4E79",
    )
    items = [
        ("bhmm::e_R0",   "Ebola\n(Kikwit 1995)",         "#C0392B", None),
        ("bhmm::n_R0",   "Norovirus\n(Derbyshire 2001)",  "#2E75B6", None),
        ("bhmm::flu_R0", "Influenza\n(England 1978)",     "#1A7B6B", None),
        (None,           "Zombie SEZR\n(prior predictive)","#ED7D31", zombie_pp["R0_samples"]),
    ]
    for ax, (var, label, col, vals_override) in zip(axes, items):
        if var is not None:
            vals = post[var].values.flatten()
        else:
            vals = vals_override
        # clip long tails for display
        clip = np.quantile(vals, 0.99)
        ax.hist(np.clip(vals, 0, clip), bins=50, color=col, alpha=0.75, density=True)
        ax.axvline(np.median(vals), color="black", linewidth=2, linestyle="--",
                   label=f"Median={np.median(vals):.2f}")
        ax.axvline(1.0, color="grey", linewidth=1, linestyle=":", label="R\u2080=1")
        ax.set_xlabel("R\u2080"); ax.set_ylabel("Density")
        ax.set_title(f"{label}")
        ax.legend(frameon=False, fontsize=7.5)
        ax.spines.top.set_visible(False); ax.spines.right.set_visible(False)
    fig.tight_layout()
    fig.savefig(FIGB / "R0_comparison.png", dpi=180, bbox_inches="tight")
    plt.close(fig)
    print("  Figure: figures/bhmm/R0_comparison.png")


def make_ppc_panel(trace, ebola_df, noro_df, flu_df, seed):
    """Posterior predictive check panel."""
    from core.bhmm.bhmm_model import build_full_bhmm as bhmm
    model = bhmm(ebola_df, noro_df, flu_df)
    with model:
        ppc = pm.sample_posterior_predictive(trace, random_seed=seed, progressbar=False)

    elig_e  = ebola_df[ebola_df.analysis_eligible]
    e_obs   = elig_e.onset.values.astype(float)
    n_obs   = noro_df.ill.values.astype(int)
    flu_obs = flu_df.in_bed.values.astype(float)

    fig, axes = plt.subplots(2, 3, figsize=(15, 8))
    fig.suptitle("Posterior Predictive Checks", fontsize=11, fontweight="bold", color="#1F4E79")

    ppd = ppc.posterior_predictive

    results = {}
    for i, (name, obs, var, col) in enumerate([
        ("Ebola",     e_obs,   "bhmm::ebola_obs", "#C0392B"),
        ("Norovirus", n_obs,   "bhmm::noro_obs",  "#2E75B6"),
        ("Influenza", flu_obs, "bhmm::flu_obs",   "#1A7B6B"),
    ]):
        samples = ppd[var].values.reshape(-1, len(obs))
        lo = np.quantile(samples, 0.05, axis=0)
        hi = np.quantile(samples, 0.95, axis=0)
        cov = float(np.mean((obs >= lo) & (obs <= hi)))
        results[name] = cov

        # Top row: observed vs predicted mean scatter
        ax = axes[0, i]
        pred_mean = samples.mean(axis=0)
        ax.scatter(obs, pred_mean, alpha=0.6, color=col, s=20)
        lim = max(obs.max(), pred_mean.max()) * 1.05
        ax.plot([0, lim], [0, lim], "k--", lw=1, alpha=0.5)
        ax.set_xlabel("Observed"); ax.set_ylabel("Predicted mean")
        ax.set_title(f"{name}\nPPC: {cov:.1%} in 90% PI")
        ax.spines.top.set_visible(False); ax.spines.right.set_visible(False)

        # Bottom row: coverage bar
        ax2 = axes[1, i]
        x = np.arange(len(obs))
        ax2.fill_between(x, lo, hi, alpha=0.3, color=col, label="90% PI")
        ax2.scatter(x, obs, color=col, s=10, zorder=5, label="Observed")
        ax2.set_xlabel("Observation index"); ax2.set_ylabel("Count")
        ax2.legend(frameon=False, fontsize=7.5)
        ax2.spines.top.set_visible(False); ax2.spines.right.set_visible(False)

    fig.tight_layout()
    fig.savefig(FIGB / "ppc_panel.png", dpi=180, bbox_inches="tight")
    plt.close(fig)
    print("  Figure: figures/bhmm/ppc_panel.png")

    for name, cov in results.items():
        status = "PASS" if cov >= 0.80 else "FAIL"
        print(f"  PPC {name:12s}: {cov:.1%} in 90% PI  [{status}]")

    return results


def make_convergence_panel(summary):
    """Rhat and ESS diagnostic figure."""
    key = ["bhmm::e_R0", "bhmm::flu_R0", "bhmm::n_R0",
           "bhmm::log_intercept_e", "bhmm::log_intercept_flu",
           "bhmm::sigma_rw_e", "bhmm::sigma_rw_flu",
           "bhmm::e_alpha_nb", "bhmm::flu_alpha_nb",
           "bhmm::class_re_sd", "bhmm::hyper_log_R0_mu", "bhmm::hyper_log_R0_sd"]
    avail = [p.replace("bhmm::", "") for p in key if p in summary.index]
    sub   = summary.loc[[f"bhmm::{p}" for p in avail]]
    sub.index = avail

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle("MCMC Convergence Diagnostics", fontsize=11, fontweight="bold", color="#1F4E79")

    rhat_cols = ["#D5F5D5" if r <= 1.01 else "#FFF3CD" if r <= 1.05 else "#FDEBEA"
                 for r in sub.r_hat]
    ax1.barh(avail, sub.r_hat, color=rhat_cols, edgecolor="grey", alpha=0.9)
    ax1.axvline(1.05, color="#C0392B", ls="--", lw=1, label="R\u0302=1.05")
    ax1.axvline(1.01, color="grey", ls=":", lw=1, label="R\u0302=1.01")
    ax1.set_xlabel("R\u0302 (potential scale reduction factor)")
    ax1.set_title("Convergence: R\u0302 per parameter")
    ax1.legend(frameon=False, fontsize=8)
    ax1.spines.top.set_visible(False); ax1.spines.right.set_visible(False)

    ess_cols = ["#D5F5D5" if e >= 400 else "#FFF3CD" if e >= 100 else "#FDEBEA"
                for e in sub.ess_bulk]
    ax2.barh(avail, sub.ess_bulk, color=ess_cols, edgecolor="grey", alpha=0.9)
    ax2.axvline(400, color="#375623", ls="--", lw=1, label="ESS=400 (4-chain threshold)")
    ax2.axvline(100, color="grey", ls=":", lw=1, label="ESS=100 minimum")
    ax2.set_xlabel("ESS bulk")
    ax2.set_title("ESS: effective sample size per parameter")
    ax2.legend(frameon=False, fontsize=8)
    ax2.spines.top.set_visible(False); ax2.spines.right.set_visible(False)

    fig.tight_layout()
    fig.savefig(FIGB / "convergence_panel.png", dpi=180, bbox_inches="tight")
    plt.close(fig)
    print("  Figure: figures/bhmm/convergence_panel.png")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Run BHMM v5")
    parser.add_argument("--quick",         action="store_true",
                        help="Quick sanity check: 300 draws x 2 chains")
    parser.add_argument("--draws",         type=int,   default=2000)
    parser.add_argument("--chains",        type=int,   default=4)
    parser.add_argument("--target_accept", type=float, default=0.95)
    parser.add_argument("--seed",          type=int,   default=20260914)
    args = parser.parse_args()

    print("=" * 62)
    print("BHMM v5  —  Bayesian Hierarchical Mechanistic Model")
    print("Real diseases: Ebola | Norovirus | Influenza England 1978")
    print("Reference arm: Zombie SEZR (prior-predictive; no data)")
    print(f"Seed: {args.seed}  |  Use same seed for reproducibility")
    print("=" * 62)

    # Load all real data
    ebola_df, noro_df, flu_df = load_data()

    # Zombie prior predictive (always runs; no data involved)
    zombie_pp = run_zombie_prior_predictive()

    # BHMM sampling
    draws        = 300    if args.quick else args.draws
    chains       = 2      if args.quick else args.chains
    target_acc   = 0.90   if args.quick else args.target_accept
    seed         = args.seed
    out_name     = "bhmm_trace_quick" if args.quick else "bhmm_trace_full"

    print(f"\n[BHMM] {draws} draws x {chains} chains  |  "
          f"target_accept={target_acc}  |  seed={seed}")

    trace = run_bhmm(ebola_df, noro_df, flu_df, draws, chains, target_acc, seed)

    print("\n[OUTPUTS]")
    summary, diag = save_outputs(trace, out_name)

    print("\n[FIGURES]")
    make_r0_comparison(trace, zombie_pp)
    make_convergence_panel(summary)

    if not args.quick:
        print("\n[PPC]")
        make_ppc_panel(trace, ebola_df, noro_df, flu_df, seed)

    print("\n[DONE] — All outputs written.")
    print("  Run scripts/06_build_reports.py to generate PDF reports.")


if __name__ == "__main__":
    main()
