"""
scripts/01_prepare_data.py
--------------------------
Prepare canonical analysis-ready datasets from raw data files.
Adds eligibility flags, derived columns, and SHA-256 provenance.

Run before any model fitting:
    python scripts/01_prepare_data.py

No synthetic data is created. All canonical files are derived from
real published raw data files in data/raw/.
"""
import sys, hashlib, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pandas as pd, numpy as np

ROOT = Path(__file__).resolve().parents[1]
RAW  = ROOT / "data" / "raw"
CAN  = ROOT / "data" / "canonical"
CAN.mkdir(exist_ok=True)

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def prepare_ebola():
    df = pd.read_csv(RAW / "ebola" / "ebola_kikwit_1995.csv", parse_dates=["date"])
    df["day"]               = (df.date - df.date.min()).dt.days
    df["analysis_eligible"] = df.reporting.astype(bool)
    # 14-day lagged CFR (onset-to-death lag; descriptive only)
    df["cfr_cumulative_lag14"] = (
        df.death.cumsum() / df.onset.shift(14).cumsum().replace(0, np.nan)
    ).clip(0, 1)
    df["ill"] = (df.onset > 0).astype(int)
    out = CAN / "ebola_kikwit_1995_analysis_ready.csv"
    df.to_csv(out, index=False)
    print(f"Ebola:     {len(df)} rows, {df.analysis_eligible.sum()} eligible | {sha256(out)[:12]}...")

def prepare_norovirus():
    df = pd.read_csv(RAW / "norovirus" / "norovirus_derbyshire_2001_school.csv")
    # CRITICAL: outcome is ill = (start_illness > 0), NOT day_absent
    df["ill"]                 = (df.start_illness > 0).astype(int)
    df["class10_outlier_flag"]= (df["class"] == 10).astype(int)
    df["class3_zero_flag"]    = (df["class"] == 3).astype(int)
    out = CAN / "norovirus_derbyshire_2001_analysis_ready.csv"
    df.to_csv(out, index=False)
    print(f"Norovirus: {len(df)} rows, {df.ill.sum()} ill | {sha256(out)[:12]}...")

def prepare_influenza():
    # Influenza England 1978 from Murray (1978) BMJ 1(6112):587
    # in_bed = students currently ill = I(t) prevalence (direct observation)
    df = pd.read_csv(RAW / "influenza" / "influenza_england_1978.csv", parse_dates=["date"])
    df["analysis_eligible"] = True   # all 14 days eligible
    df["day_of_week"]       = df.date.dt.day_name()
    out = CAN / "influenza_england_1978_analysis_ready.csv"
    df.to_csv(out, index=False)
    print(f"Influenza: {len(df)} days, peak in_bed={df.in_bed.max()} | {sha256(out)[:12]}...")

def write_sha256sums():
    rows = []
    for f in sorted(CAN.iterdir()):
        rows.append(f"{sha256(f)}  {f.name}")
    (ROOT / "data" / "SHA256SUMS.txt").write_text("\n".join(rows) + "\n")
    print(f"SHA256SUMS written ({len(rows)} files)")

if __name__ == "__main__":
    print("Preparing canonical datasets...")
    prepare_ebola()
    prepare_norovirus()
    prepare_influenza()
    write_sha256sums()
    print("Done. Verify: sha256sum -c data/SHA256SUMS.txt")
