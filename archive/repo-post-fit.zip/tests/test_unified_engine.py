"""Smoke tests for the BHMM v5 model build."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd
import pytest

CAN = Path(__file__).resolve().parents[1] / "data" / "canonical"

def test_model_builds():
    """BHMM model should build with correct free RVs."""
    from core.bhmm.bhmm_model import build_full_bhmm
    ebola = pd.read_csv(CAN / "ebola_kikwit_1995_analysis_ready.csv")
    noro  = pd.read_csv(CAN / "norovirus_derbyshire_2001_analysis_ready.csv")
    flu   = pd.read_csv(CAN / "influenza_england_1978_analysis_ready.csv")
    model = build_full_bhmm(ebola, noro, flu)
    free  = [rv.name for rv in model.free_RVs]
    assert "bhmm::e_log_R0_raw"   in free, "Ebola R0 raw missing"
    assert "bhmm::flu_log_R0_raw" in free, "Influenza R0 raw missing"
    assert "bhmm::n_log_R0_raw"   in free, "Norovirus R0 raw missing"
    assert "bhmm::log_intercept_e"   in free
    assert "bhmm::log_intercept_flu" in free
    assert "bhmm::log_rw_e"   in free
    assert "bhmm::log_rw_flu" in free
    # Rabies should NOT be present
    assert not any("rabies" in rv.lower() for rv in free), \
        "Stale Rabies RVs found in model"
    # r_log naming: flu_log replaces r_log; no bare r_R0 should exist
    assert "bhmm::r_R0" not in free, "Stale Rabies r_R0 found"
    print(f"Free RVs ({len(free)}): {free}")

def test_km_attack_rate():
    """K-M attack rate should be correct for known R0 values."""
    import pytensor.tensor as pt
    from core.bhmm.bhmm_model import km_attack_rate
    # R0=2: K-M AR ≈ 0.797 (Kermack & McKendrick 1927)
    R0 = pt.as_tensor_variable(2.0)
    AR = km_attack_rate(R0).eval()
    assert abs(AR - 0.797) < 0.01, f"K-M AR at R0=2 wrong: {AR:.3f}"
    # R0<1: AR should be small (< 0.02); exact 0 not guaranteed due to lower clip
    # At R0=0.5: true K-M root = 0 but the clip to 1e-6 and Newton init 1-exp(-0.5)≈0.39
    # means the converged value is near the lower clip; verify it is small
    R0_sub = pt.as_tensor_variable(0.5)
    AR_sub = km_attack_rate(R0_sub).eval()
    assert AR_sub < 0.05, f"K-M AR at R0=0.5 should be small: {AR_sub:.3f}"

def test_influenza_data_shape():
    """Influenza dataset should have 14 rows, in_bed > 0 all days."""
    flu = pd.read_csv(CAN / "influenza_england_1978_analysis_ready.csv")
    assert len(flu) == 14, f"Expected 14 days, got {len(flu)}"
    assert (flu.in_bed > 0).all(), "All days should have in_bed > 0"
    assert flu.N.iloc[0] == 763, f"N should be 763, got {flu.N.iloc[0]}"
    assert flu.analysis_eligible.all(), "All days should be eligible"

def test_no_synthetic_data_in_bhmm():
    """Verify no zombie raw data files are read by the BHMM."""
    import ast
    model_src = (Path(__file__).parents[1] / "core" / "bhmm" / "bhmm_model.py").read_text()
    assert "sezr_initial_population" not in model_src
    assert "sezr_person_day_observations" not in model_src
    assert "rabies" not in model_src.lower(), "Stale Rabies references in bhmm_model.py"

if __name__ == "__main__":
    test_model_builds()
    test_km_attack_rate()
    test_influenza_data_shape()
    test_no_synthetic_data_in_bhmm()
    print("All tests passed.")
