"""
core/bhmm/bhmm_model.py
-----------------------
Unified Bayesian Hierarchical Mechanistic Model (BHMM) — v5.

Architecture:
  - Three real-disease arms share a hyperprior on log(R0) (partial pooling).
  - Ebola: NB on daily onset (active-window rows only; analysis_eligible=TRUE).
  - Norovirus: Bernoulli logit per student with 15 class random intercepts.
  - Influenza 1978: NB on in_bed[t] = I(t) prevalence directly.
  - Zombie SEZR: prior-predictive only (see prior_predictive.py); no likelihood here.

Key modelling decisions (documented in docs/DATA_HANDLING_DECISIONS.md):
  1. Non-centred R0 reparameterisation eliminates Neal's funnel divergences.
     (Betancourt & Girolami 2015, MCMC Using Hamiltonian Dynamics)
  2. Gaussian random walk on log(beta_t) absorbs temporal autocorrelation.
     init_dist matches innovation distribution.
     (Durbin & Koopman 2012, Time Series Analysis by State Space Methods)
  3. log_intercept per disease anchors ODE trajectory scale identifiably;
     HalfNormal scale factors are non-identifiable with GRW and are not used.
  4. K-M final-size equation solved by 8-step Newton iteration for Norovirus.
     (Kermack & McKendrick 1927; Diekmann et al. 2010)
  5. Influenza observation model: in_bed[t] ~ NB(mu=ODE_I(t)); prevalence
     observed directly, no gamma-flux conversion required.
     (Murray 1978 BMJ; Vynnycky & White 2010)

References:
  Legrand et al. (2007). Epidemics, 21(3), 183-197.
  Althaus (2014). PLOS Currents Outbreaks.
  Khan et al. (1999). J Infect Dis 179 Suppl 1:S76-86.
  Heijne et al. (2012). Epidemics, 4(4), 164-171.
  O'Neill & Marks (2005). Stat Med 24(13):2011-2024.
  Hampson et al. (2009). PLoS Biol 7(12):e1000053.
  Murray (1978). Br Med J 1(6112):587.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pymc as pm
import pytensor.tensor as pt
from scipy.integrate import solve_ivp

from core.bhmm.priors import EBOLA_PRIOR, INFLUENZA_PRIOR, NOROVIRUS_PRIOR


# ---------------------------------------------------------------------------
# ODE solver (mean-field SEIRD; Theorem 1 in mathematical_framework.pdf)
# ---------------------------------------------------------------------------

def ode_prevalence(
    log_beta: float,
    log_sigma: float,
    log_gamma: float,
    mu: float,
    N: int,
    I0: int,
    T_end: float,
    n_steps: int | None = None,
) -> np.ndarray:
    """
    Solve the SEIRD mean-field ODE and return I(t) as a numpy array.

    Parameters
    ----------
    log_beta  : log of transmission rate (day^-1)
    log_sigma : log of incubation rate (day^-1); 1/sigma = mean incubation period
    log_gamma : log of removal rate (day^-1); 1/gamma = mean infectious period
    mu        : case fatality ratio (dimensionless, in [0,1])
    N         : population size
    I0        : initial infectious count
    T_end     : total simulation time (days)
    n_steps   : number of time points to evaluate (default: T_end + 1)

    Returns
    -------
    I_t : np.ndarray of shape (n_steps,), clipped to [0, inf)
    """
    beta  = np.exp(float(log_beta))
    sigma = np.exp(float(log_sigma))
    gamma = np.exp(float(log_gamma))
    mu    = float(mu)

    n_steps = n_steps or int(T_end) + 1
    t_eval  = np.linspace(0, T_end, n_steps)
    y0      = [N - I0, 0.0, float(I0), 0.0, 0.0]

    def rhs(t, y):
        S, E, I, R, D = y
        foi = beta * I / N          # force of infection
        return [
            -foi * S,               # dS/dt
            foi * S - sigma * E,    # dE/dt
            sigma * E - gamma * I,  # dI/dt
            gamma * (1 - mu) * I,   # dR/dt
            gamma * mu * I,         # dD/dt
        ]

    sol = solve_ivp(
        rhs, [0, T_end], y0, t_eval=t_eval,
        method="RK45", rtol=1e-6, atol=1e-8,
    )
    return np.clip(sol.y[2], 0, None)


# ---------------------------------------------------------------------------
# K-M final-size solver (Theorem 3 in mathematical_framework.pdf)
# ---------------------------------------------------------------------------

def km_attack_rate(R0_val: pt.TensorVariable) -> pt.TensorVariable:
    """
    Solve AR = 1 - exp(-R0 * AR) by 8-step Newton iteration.

    Converges quadratically from AR_0 = 1 - exp(-R0).
    8 iterations achieve machine precision for R0 in (1, 20).
    (Lemma 3: Newton convergence for K-M equation)

    Parameters
    ----------
    R0_val : PyTensor tensor representing the basic reproduction number

    Returns
    -------
    AR : PyTensor tensor, attack rate in [1e-6, 1 - 1e-6]
    """
    R0 = pt.clip(R0_val, 0.01, 20.0)
    AR = 1.0 - pt.exp(-R0)                   # good initial guess
    for _ in range(8):
        f  = AR - 1.0 + pt.exp(-R0 * AR)
        df = 1.0 + R0 * pt.exp(-R0 * AR)
        AR = pt.clip(AR - f / df, 1e-6, 1.0 - 1e-6)
    return AR


# ---------------------------------------------------------------------------
# Full BHMM
# ---------------------------------------------------------------------------

def build_full_bhmm(
    ebola_df: pd.DataFrame,
    noro_df: pd.DataFrame,
    influenza_df: pd.DataFrame,
    n_class: int = 15,
) -> pm.Model:
    """
    Build the unified BHMM with three real-disease arms.

    All three arms share a hyperprior on log(R0), implementing Bayesian
    partial pooling across diseases (Gelman et al. 2013, BDA3 Ch. 5).

    Parameters
    ----------
    ebola_df     : Analysis-ready Ebola canonical dataset
    noro_df      : Analysis-ready Norovirus canonical dataset
    influenza_df : Influenza England 1978 canonical dataset
    n_class      : Number of Norovirus school classes (15)

    Returns
    -------
    model : pm.Model — ready for pm.sample()
    """

    # ── Ebola data preparation ──────────────────────────────────────────────
    # Only analysis_eligible=TRUE rows enter the likelihood.
    # reporting=FALSE rows (n=53) are structural zeros; they are excluded.
    # See docs/DATA_HANDLING_DECISIONS.md §1 for rationale.
    elig_e     = ebola_df[ebola_df.analysis_eligible].copy()
    ebola_obs  = elig_e.onset.values.astype(float)
    ebola_days = elig_e.day.values.astype(np.int32)
    T_e        = int(ebola_df.day.max()) + 2   # GRW length; covers full epidemic window

    # ── Norovirus data preparation ──────────────────────────────────────────
    # Outcome: ill = (start_illness > 0). NOT day_absent (mediator, not outcome).
    # class indexed 0-14 for pm.Normal shape.
    noro_ill = noro_df.ill.values.astype(int)
    noro_cls = (noro_df["class"].values - 1).astype(int)

    # ── Influenza 1978 data preparation ─────────────────────────────────────
    # in_bed[t] is a PREVALENCE measure: students currently ill = I(t).
    # Observation model: in_bed[t] ~ NB(mu = ODE_I(t) × scale, alpha).
    # No gamma-flux conversion needed (unlike Ebola incidence).
    flu_obs  = influenza_df.in_bed.values.astype(float)
    T_flu    = len(flu_obs)
    N_flu    = int(influenza_df.N.iloc[0])   # 763, known exactly

    # ── Precompute ODE base trajectories at prior-mean parameters ───────────
    # These are fixed numpy arrays; they are not re-solved inside NUTS.
    # The GRW captures time-varying deviations from this baseline.
    e_base = ode_prevalence(
        EBOLA_PRIOR.log_beta_mu, EBOLA_PRIOR.log_sigma_mu,
        EBOLA_PRIOR.log_gamma_mu, 0.81, 1000, 1, float(T_e), T_e,
    )
    flu_base = ode_prevalence(
        INFLUENZA_PRIOR.log_beta_mu, INFLUENZA_PRIOR.log_sigma_mu,
        INFLUENZA_PRIOR.log_gamma_mu, 0.001, N_flu, 1, float(T_flu - 1), T_flu,
    )
    e_base_t   = pt.as_tensor_variable(e_base.astype(np.float64))
    flu_base_t = pt.as_tensor_variable(flu_base.astype(np.float64))

    # Prior-mean R0 for each disease (used as anchor for non-centred log_R0)
    e_R0_base   = np.exp(EBOLA_PRIOR.log_beta_mu)   / np.exp(EBOLA_PRIOR.log_gamma_mu)
    flu_R0_base = np.exp(INFLUENZA_PRIOR.log_beta_mu) / np.exp(INFLUENZA_PRIOR.log_gamma_mu)
    n_R0_base   = np.exp(NOROVIRUS_PRIOR.log_beta_mu) / np.exp(NOROVIRUS_PRIOR.log_gamma_mu)

    with pm.Model(name="bhmm") as model:

        # ── Hyperpriors: shared cross-disease log(R0) distribution ─────────
        # Partial pooling: each disease's R0 is drawn from a shared distribution.
        # This allows borrowing of information while keeping posteriors distinct.
        # Weakly informative: Normal(0.5, 1.0) spans R0 in approximately [0.2, 12].
        hyper_log_R0_mu = pm.Normal("hyper_log_R0_mu", mu=0.5, sigma=1.0)
        hyper_log_R0_sd = pm.HalfNormal("hyper_log_R0_sd", sigma=0.5)

        # ── Non-centred disease-specific R0 (Theorem 4) ─────────────────────
        # Raw unit-normal draws; actual log_R0 is a Deterministic.
        # Eliminates Neal's funnel: conditional distribution of raw is N(0,1)
        # regardless of hyper_log_R0_sd value.
        e_log_R0_raw   = pm.Normal("e_log_R0_raw",   mu=0, sigma=1)
        flu_log_R0_raw = pm.Normal("flu_log_R0_raw", mu=0, sigma=1)
        n_log_R0_raw   = pm.Normal("n_log_R0_raw",   mu=0, sigma=1)

        e_log_R0 = pm.Deterministic(
            "e_log_R0",
            hyper_log_R0_mu + np.log(e_R0_base)
            + (hyper_log_R0_sd + 0.1) * e_log_R0_raw,
        )
        flu_log_R0 = pm.Deterministic(
            "flu_log_R0",
            hyper_log_R0_mu + np.log(flu_R0_base)
            + (hyper_log_R0_sd + 0.1) * flu_log_R0_raw,
        )
        n_log_R0 = pm.Deterministic(
            "n_log_R0",
            hyper_log_R0_mu + np.log(n_R0_base)
            + (hyper_log_R0_sd + 0.1) * n_log_R0_raw,
        )

        e_R0   = pm.Deterministic("e_R0",   pm.math.exp(e_log_R0))
        flu_R0 = pm.Deterministic("flu_R0", pm.math.exp(flu_log_R0))
        n_R0   = pm.Deterministic("n_R0",   pm.math.exp(n_log_R0))

        # ── NB overdispersion ───────────────────────────────────────────────
        # HalfNormal priors calibrated to pre-fit Var/Mean diagnostics.
        # Ebola: Var/Mean=2.60; Influenza: Var/Mean=103.6 (epidemic arc shape).
        e_alpha   = pm.HalfNormal("e_alpha_nb",   sigma=float(EBOLA_PRIOR.nb_alpha_mu))
        flu_alpha = pm.HalfNormal("flu_alpha_nb", sigma=float(INFLUENZA_PRIOR.nb_alpha_mu))

        # ── Norovirus class random intercepts ───────────────────────────────
        # Handles Class 10 outlier (AR=66.7%) and Class 3 structural zero
        # through partial pooling — not imputation, not deletion.
        # class_re[k] ~ Normal(0, class_re_sd) for k=0,...,14
        class_re_sd = pm.HalfNormal("class_re_sd", sigma=1.0)
        class_re    = pm.Normal("class_re", mu=0.0, sigma=class_re_sd, shape=n_class)

        # ── Ebola: log-intercept + GRW on log(beta_t) ──────────────────────
        # log_intercept_e: anchors ODE trajectory to observed onset scale.
        # Prior centred near log(gamma) = log(1/6) ≈ -1.79 (daily removal rate).
        # GRW: sigma_rw_e ~ HalfNormal(0.30); init_dist matches innovation
        # distribution (Lemma 5: Durbin & Koopman 2012).
        log_intercept_e = pm.Normal("log_intercept_e", mu=-1.8, sigma=1.5)
        sigma_rw_e      = pm.HalfNormal("sigma_rw_e", sigma=0.3)
        log_rw_e        = pm.GaussianRandomWalk(
            "log_rw_e", mu=0, sigma=sigma_rw_e,
            init_dist=pm.Normal.dist(0, sigma_rw_e),  # matches innovation distribution
            shape=T_e,
        )
        # E[onset_t] = exp(log_intercept_e + log_rw_e[t]) * e_base[t]
        # e_base is already in count units (ODE with N=1000); no N_E multiplier.
        e_mu_obs = pt.clip(
            pt.exp(log_intercept_e + log_rw_e[ebola_days]) * e_base_t[ebola_days],
            0.01, 1e9,
        )

        # ── Influenza 1978: log-intercept + GRW on log(beta_t) ─────────────
        # in_bed[t] is a direct prevalence observation: in_bed[t] ≈ I(t).
        # No gamma-flux conversion: E[in_bed[t]] = ODE_I(t) * scale.
        # Var/Mean=103.6 reflects epidemic trajectory shape, not overdispersion;
        # flu_alpha_nb prior = HalfNormal(50) to allow small alpha values.
        # GRW: init_dist matches innovation distribution (Lemma 5).
        log_intercept_flu = pm.Normal("log_intercept_flu", mu=0.0, sigma=2.0)
        sigma_rw_flu      = pm.HalfNormal("sigma_rw_flu", sigma=0.3)
        log_rw_flu        = pm.GaussianRandomWalk(
            "log_rw_flu", mu=0, sigma=sigma_rw_flu,
            init_dist=pm.Normal.dist(0, sigma_rw_flu),  # matches innovation distribution
            shape=T_flu,
        )
        # E[in_bed_t] = exp(log_intercept_flu + log_rw_flu[t]) * flu_base[t]
        # flu_base is in count units (ODE with N=763); no N_flu multiplier.
        flu_mu_obs = pt.clip(
            pt.exp(log_intercept_flu + log_rw_flu) * flu_base_t,
            0.01, 1e9,
        )

        # ── Norovirus: attack rate via K-M equation ─────────────────────────
        # Population-level attack rate from the K-M final-size relation.
        # Per-student log-odds = logit(AR_KM) + class_RE[class_id].
        n_AR       = km_attack_rate(n_R0)
        n_log_odds = pm.math.log(n_AR) - pm.math.log(1.0 - n_AR)
        n_logit_p  = n_log_odds + class_re[noro_cls]

        # ── Likelihoods ──────────────────────────────────────────────────────
        # Ebola: NB on daily onset (analysis_eligible=TRUE only; n=139 days)
        pm.NegativeBinomial("ebola_obs", mu=e_mu_obs, alpha=e_alpha,
                            observed=ebola_obs)

        # Influenza 1978: NB on in_bed (prevalence directly; n=14 days)
        pm.NegativeBinomial("flu_obs", mu=flu_mu_obs, alpha=flu_alpha,
                            observed=flu_obs)

        # Norovirus: Bernoulli logit per student (n=492 students)
        pm.Bernoulli("noro_obs", logit_p=n_logit_p, observed=noro_ill)

    return model
