"""
Observation likelihood functions for the Bayesian Hierarchical Mechanistic Model.

Maps ODE mean-field trajectories (continuous deterministic output) to the
discrete observations in each dataset via appropriate statistical distributions.

Likelihood choices follow directly from the pre-fit diagnostics (v5 reports):
  Ebola  : Negative Binomial (Var/Mean=2.60; right-skewed counts)
  Rabies : Negative Binomial (Var/Mean=1.10; mild overdispersion + autocorrelation)
  Norovirus: Bernoulli logit (binary outcome per student; class random intercept)

NEVER used:
  Poisson           -- ruled out by overdispersion in all three datasets
  Gaussian          -- ruled out by discrete non-negative counts / binary outcome
  Any synthetic data -- zombie appears only as prior predictive (no likelihood)
"""
from __future__ import annotations
import numpy as np
import pymc as pm
import pytensor.tensor as pt
from typing import Optional


# ------------------------------------------------------------------ #
#  Ebola: Negative Binomial on daily active-window onset counts       #
# ------------------------------------------------------------------ #
def ebola_likelihood(
    obs_counts: np.ndarray,       # shape (T,) — daily onset on analysis_eligible days
    mu_ode: pt.TensorVariable,    # ODE I(t) scaled to expected daily incidence
    alpha: pt.TensorVariable,     # NB overdispersion (1/alpha = extra variance)
    name: str = "ebola_obs",
) -> pm.NegativeBinomial:
    """
    Negative Binomial likelihood for daily Ebola onset counts.

    NB parameterisation: E[Y] = mu, Var[Y] = mu + mu²/alpha.
    As alpha → ∞, NB → Poisson.  alpha ≈ 1 corresponds to Var ≈ 2·mu,
    consistent with the pre-fit Var/Mean=2.60 finding.

    Only applied to analysis_eligible rows (reporting=TRUE).
    reporting=FALSE rows contribute no likelihood — they are retained in
    the data file with analysis_eligible=FALSE but never passed here.
    """
    # Clip to avoid log(0) in sampler; mu must be > 0
    mu_safe = pt.clip(mu_ode, 1e-6, None)
    return pm.NegativeBinomial(name, mu=mu_safe, alpha=alpha, observed=obs_counts)


# ------------------------------------------------------------------ #
#  Rabies: Negative Binomial on monthly case counts                   #
# ------------------------------------------------------------------ #
def rabies_likelihood(
    obs_counts: np.ndarray,       # shape (T,) — monthly case counts (all 62 months)
    mu_ode: pt.TensorVariable,    # ODE I(t) summed/scaled to monthly expected counts
    alpha: pt.TensorVariable,
    name: str = "rabies_obs",
) -> pm.NegativeBinomial:
    """
    Negative Binomial likelihood for monthly rabies case counts.

    All 62 months are included in the likelihood.  The surveillance_concern_flag
    (2004-2006) is addressed via a sensitivity analysis (script 04b), not by
    deleting rows from the likelihood.

    The NB overdispersion parameter also partially absorbs the lag-1
    autocorrelation (r=0.52) that the ODE trajectory cannot capture on its own.
    A full AR(1) extension is documented in docs/BHMM_ARCHITECTURE.md §4.
    """
    mu_safe = pt.clip(mu_ode, 1e-6, None)
    return pm.NegativeBinomial(name, mu=mu_safe, alpha=alpha, observed=obs_counts)


# ------------------------------------------------------------------ #
#  Norovirus: Bernoulli logit + class random intercepts               #
# ------------------------------------------------------------------ #
def norovirus_likelihood(
    obs_ill: np.ndarray,           # shape (N,) — binary illness indicator (start_illness>0)
    class_ids: np.ndarray,         # shape (N,) — integer class index 0..K-1
    log_odds_base: pt.TensorVariable,   # log-odds from ODE-implied attack rate
    class_re: pt.TensorVariable,        # shape (K,) — class-level random intercepts
    name: str = "norovirus_obs",
) -> pm.Bernoulli:
    """
    Bernoulli likelihood for student-level illness outcome.

    Outcome: ill = (start_illness > 0)  [NOT day_absent > 0].
    This distinction is mandatory — see DATA_HANDLING_DECISIONS.md §2.

    Class random intercepts absorb between-class heterogeneity, including:
    - Class 10's anomalous AR=66.7% (gets its own intercept, does not bias β)
    - Class 3's structural zero (gets a strongly negative intercept, pulled
      toward global mean by partial pooling — no imputation performed)

    Varying class sizes (20–86 students) are handled naturally by the
    individual-level likelihood — no resampling or balancing is applied.
    """
    logit_p = log_odds_base + class_re[class_ids]
    return pm.Bernoulli(name, logit_p=logit_p, observed=obs_ill)
